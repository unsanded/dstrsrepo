#ifndef XMMSC_WINDOWS_H
#define XMMSC_WINDOWS_H

#ifdef _MSC_VER
#define inline __inline
#endif

#endif
