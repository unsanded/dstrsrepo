#ifndef XMMSC_UNISTD_H
#define XMMSC_UNISTD_H

#ifndef _MSC_VER
#include <unistd.h>
#endif

#endif
